# Cloudflare Pages Deployment Guide

## Prerequisites

1. Install Wrangler CLI:
```bash
npm install -g wrangler
```

2. Login to Cloudflare:
```bash
wrangler login
```

## Step 1: Create D1 Database

```bash
wrangler d1 create clipboard-db
```

Copy the `database_id` from the output and update `wrangler.toml`:

```toml
[[d1_databases]]
binding = "DB"
database_name = "clipboard-db"
database_id = "YOUR_DATABASE_ID_HERE"  # Replace with your actual ID
```

## Step 2: Initialize Database

Run the SQL initialization script:

```bash
wrangler d1 execute clipboard-db --file=./scripts/d1-init.sql
```

## Step 3: Install Dependencies

```bash
npm install @cloudflare/next-on-pages
```

Add build script to `package.json`:

```json
{
  "scripts": {
    "pages:build": "npx @cloudflare/next-on-pages",
    "pages:deploy": "wrangler pages deploy .vercel/output/static",
    "pages:dev": "npx wrangler pages dev .vercel/output/static --compatibility-date=2024-01-01 --compatibility-flag=nodejs_compat"
  }
}
```

## Step 4: Build and Deploy

```bash
# Build for Cloudflare Pages
npm run pages:build

# Deploy to Cloudflare Pages
npm run pages:deploy
```

## Step 5: Configure D1 Binding in Cloudflare Dashboard

1. Go to Cloudflare Dashboard > Pages > Your Project > Settings > Functions
2. Add D1 database binding:
   - Variable name: `DB`
   - D1 database: Select `clipboard-db`

## Environment Variables

No additional environment variables needed. The password is stored in the D1 database.

## Changing the Password

To change the login password, run:

```bash
wrangler d1 execute clipboard-db --command="UPDATE settings SET value = 'your-new-password' WHERE key = 'password'"
```

## Default Credentials

- Password: `clipboard123` (change this after deployment!)

## Features

- Single password authentication (no user registration)
- Multiple topics/categories for organizing content
- Ctrl+S keyboard shortcut for quick saving
- Dark/Light mode toggle
- Real-time last saved timestamp
- Responsive design
- All data stored in Cloudflare D1
