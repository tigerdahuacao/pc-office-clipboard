import { NextResponse } from "next/server"
import { getD1, mockDB } from "@/lib/d1"

export const runtime = "edge"

export async function POST(request: Request) {
  try {
    const { password } = await request.json()

    if (!password) {
      return NextResponse.json({ error: "Password required" }, { status: 400 })
    }

    const db = getD1()
    let storedPassword: string

    if (db) {
      const result = await db
        .prepare("SELECT value FROM settings WHERE key = ?")
        .bind("password")
        .first<{ value: string }>()
      storedPassword = result?.value || "clipboard123"
    } else {
      storedPassword = await mockDB.getPassword()
    }

    if (password === storedPassword) {
      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: "Invalid password" }, { status: 401 })
  } catch (error) {
    console.error("Auth error:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}
